package L06Ferrari;

public class Main {
    public static void main(String[] args) {

    }
}
