package L05BorderControl;

public interface Identifiable {
    String getId();
}
