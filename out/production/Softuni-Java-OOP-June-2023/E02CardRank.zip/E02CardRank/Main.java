package E02CardRank;

public class Main {
    public static void main(String[] args) {
        System.out.println("Card Ranks:");
        CardSuits[] cardSuits = CardSuits.values();

        for (CardSuits c : cardSuits) {
            System.out.printf("Ordinal value: %d; Name value: %s%n", c.ordinal(), c.name());
        }
    }
}
