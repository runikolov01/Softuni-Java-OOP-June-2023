package E04FoodShortage;

public interface Identifiable {
    String getId();

}
