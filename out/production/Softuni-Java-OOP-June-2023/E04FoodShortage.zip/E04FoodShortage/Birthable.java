package E04FoodShortage;

public interface Birthable {
    String getBirthDate();

}
