package E05FootballTeamGenerator;

import java.util.ArrayList;
import java.util.List;

public class Team {
    private String name;
    private List<Player> players;

    public Team(String name) {
        this.setName(name);
        this.players = new ArrayList<>();

    }

    public String getName() {
        return this.name;
    }

    private void setName(String name) {
        if (name.trim().length() >= 1) {
            this.name = name;
        } else {
            throw new IllegalArgumentException("A name should not be empty.");
        }
    }

    public void addPlayer(Player player) {
        players.add(player);
    }

    public void removePlayer(String name) {
        if (players.stream().noneMatch(e -> e.getName().equals(name))) {
            throw new IllegalArgumentException("Player " + name + " is not in " + this.name + " team.");
        } else {
            this.players.remove(this.players.stream().filter(e -> e.getName().equals(name)).findFirst().orElseThrow());
        }
    }

    public double getRating() {
        return this.players.stream().mapToDouble(Player::overallSkillLevel).average().orElse(0);
    }
}
