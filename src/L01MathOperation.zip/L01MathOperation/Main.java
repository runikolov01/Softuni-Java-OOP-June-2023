package L01MathOperation;

public class Main {
    public static void main(String[] args) {

    }
}
