package E02MultipleImplementation;

public interface Birthable {
    String getBirthDate();

}
