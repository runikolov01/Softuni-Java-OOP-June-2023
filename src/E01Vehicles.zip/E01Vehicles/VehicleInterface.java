package E01Vehicles;

public interface VehicleInterface {
    void drive(double distance);
    void refuel(double liters);
}
