package E04TrafficLights;

public enum Color {
    RED,
    YELLOW,
    GREEN


}
