package car;

public interface Rentable {
    Integer getMinRentDay();

    Double getPricePerDay();
}

