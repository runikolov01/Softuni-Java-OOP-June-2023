package E03BirthdayCelebrations;

public interface Identifiable {
    String getId();

}
