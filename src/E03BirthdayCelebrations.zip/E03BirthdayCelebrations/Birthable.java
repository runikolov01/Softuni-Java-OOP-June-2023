package E03BirthdayCelebrations;

public interface Birthable {
    String getBirthDate();

}
